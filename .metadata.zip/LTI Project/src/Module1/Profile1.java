package Module1;

public class Profile1 {

	public static void main(String[] args) {
		int roll=1;
		String Name="SOUAMJIT";
		String college="Techno India";
		double score=99.5;    
		
		System.out.println("roll is " +  roll);
		System.out.println("Name is " +  Name);
		System.out.println("college is " +  college);
		System.out.println("score is " +  score);

	}

}
