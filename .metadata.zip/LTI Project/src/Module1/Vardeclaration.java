package Module1;

public class Vardeclaration {

	public static void main(String[] args) {
		int eno=100;
		String ename="SOUAMJIT";
		float sal1=50000.81f; //1 type casting
		double comm=1000.61;    
		
		System.out.println("empno is " +  eno);
		System.out.println("ename is " +  ename);
		System.out.println("salary is " +  sal1);
		System.out.println("commission is " +  comm);
		System.out.println(ename.hashCode());



	}

}
