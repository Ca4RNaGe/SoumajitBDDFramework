package Module1;

public class Emp{
	private int empId;
	private double sal;
	
	publice void accept() {
		System.out.println("this is accept method");
		
	}

	public void display() {
		System.out.println("this is display method");
	}
	
	public static void main(String[] args) {
		Emp obj=new Emp
		
	}
}
