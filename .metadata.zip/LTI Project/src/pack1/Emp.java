package pack1;

public class Emp {
	private int eno;
	private String ename;
	private double sal;
	
	public void accept()
	{
		System.out.println("accept method");
	}
	public void display()
	{
		System.out.println("display method");
	}
}
