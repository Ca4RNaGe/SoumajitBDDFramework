package interfacepack;

public class TestCircle {

	public static void main(String[] args) {
		Circle circle=new Circle(11.5f);
		System.out.println("the area is "+circle.area());
		System.out.println("perimeter is "+circle.peri());

	}

}
