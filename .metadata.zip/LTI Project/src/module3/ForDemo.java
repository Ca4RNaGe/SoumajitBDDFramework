package module3;

public class ForDemo {

	public static void main(String[] args) {
		// dsiplay 1-20
		for(int count=1; count<=10; count++)
		{
			System.out.println("soumajit"+count);
		}

	}

}
