package module3;

public class NotEg {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		
		if(a!=b)
			System.out.println("a is not equal to b");
		//if(a==b)
		//System.out.println("both are same");
		//else
		//System.out.println("both are not same");
	}

}
