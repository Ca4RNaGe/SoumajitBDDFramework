package module3;

public class WhileDemo {

	public static void main(String[] args) {
		int counter=1;
		while(counter<=20)
		{
			if(counter%2 !=0)
				System.out.println(counter);
			counter++;
		}
	}

}
