package module3;

public class DoWhileDemo {

	public static void main(String[] args) {
		int b=4;
				int fact=1;
		//4*3*2*1
		while(b>=1)
		{
			fact=fact*b;
		b--;
		}
		System.out.println("the factorial of the no is "+fact);
	}
	//	int count=1;
		
	//	do {
	//		System.out.println("Soumajit");
	//		count++;
	//	}while(count<=10);
	//int count=2;
	//		do {
	//		if(count%2==0)
	//		{
	//			System.out.println(count);
	//		}
	//		count++;
	//		}while(count<=20);
	//}
	

}
