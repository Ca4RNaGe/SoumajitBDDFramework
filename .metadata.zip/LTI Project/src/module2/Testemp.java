package module2;

public class Testemp {
    public static void main(String[] args) {
        Emp Emp=new Emp();
        Emp.accept();
        Emp.display();
	}
}
