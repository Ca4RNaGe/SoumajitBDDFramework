package module2;

public class Teststudent {

	public static void main(String[] args) {
		Student sher=new Student();
		sher.appearExam();
		sher.writing();
		sher.solveAssign();
				

	}

}
