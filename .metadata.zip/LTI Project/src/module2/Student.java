package module2;


public class Student{
		 private int rollNo;
		 private String name; 
		 private double score;
		 
		 public void writing() {
			 System.out.println("this is writing method");
		

	}
		 public void appearExam() {
			 System.out.println("this is appear exam method");
		 }
		 public void solveAssign() {
			 System.out.println("this is solve assignment method");
		 }

}
