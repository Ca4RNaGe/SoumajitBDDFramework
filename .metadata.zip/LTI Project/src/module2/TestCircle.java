package module2;

public class TestCircle {
	
	    public static void main(String[] args) {
	        Circle circle=new Circle();
	        circle.accept();
	        circle.calArea();
	        circle.calPeri();
	        circle.display();
		
	}

}
