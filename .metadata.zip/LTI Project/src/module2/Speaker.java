package module2;

public class Speaker {
	 private String Brand;
	 private int ID; 
	 private double Price;
	 

	
		

	}

}
