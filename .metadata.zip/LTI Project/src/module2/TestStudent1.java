package module2;

public class TestStudent1 {
    public static void main(String[] args) {
        student1 student1=new student1();
        student1.accept();
        student1.display();
        
        System.out.println("============================");
       System.out.println("Creating seconf obj");
       student1 student2=new student1();
       student2.accept();
       student2.display();
       
       System.out.println("============================");
       System.out.println("Creating seconf obj");
       student1 student31=new student1();
       student3.accept();
       student3.display();
 
    }
 
		
}
