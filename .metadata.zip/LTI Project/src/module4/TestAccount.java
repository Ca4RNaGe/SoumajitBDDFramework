package module4;

public class TestAccount {
	public static void main(String[] args) {
		Account account=new Account();
		System.out.println(account);
		
		System.out.println("==========================");
		System.out.println("Creating obj with parameter");
		Account account2=new Account();
		System.out.println(account2);
	}

}
