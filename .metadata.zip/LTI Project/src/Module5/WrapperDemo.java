package Module5;

public class WrapperDemo {

	public static void main(String[] args) {
//		String a="100";
//		String b="200";
//		
//		int result=Integer.parseInt(a)+Integer.parseInt(b);
//		System.out.println("result is "+result);

		//		String a="100.50";
//		String b="200.50";
//		float res=Float.parseFloat(a)+Float.parseFloat(b);
//		System.out.println(res);

        String a="100.898";
        String b="200.898";
        double res=Double.parseDouble(a)+Double.parseDouble(b);
        System.out.println(res);
	}
 
}
