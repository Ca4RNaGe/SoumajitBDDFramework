package Module5;

public class BreakDemo {

	public static void main(String[] args) {
		for(int a=1; a<10; a++)
		{
			if (a==5)
				//break;
				continue;
			else
				System.out.println(a);
		}

	}
 
}
