package inheritance;

public class Rectangle extends Shape {
	public void calArea(String s,int len,int bre)
	{
		System.out.println("this is calculate area of the Rectangle class");
		System.out.println("the area "+ (len*bre));
	}


}
