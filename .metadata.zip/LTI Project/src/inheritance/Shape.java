package inheritance;

public class Shape {
	public void calArea(String s,int len,int bre)
	{
		System.out.println("this is calculate area of the shape class");
	}

}
