package test;

public class b {
	public static void main(String[] args) {
		System.out.println("GG");
	}

}
